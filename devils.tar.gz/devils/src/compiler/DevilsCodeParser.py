# Generated from DevilsCode.g4 by ANTLR 4.5.1
# encoding: utf-8
from antlr4 import *
from io import StringIO

def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\3\26")
        buf.write("\u009c\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16")
        buf.write("\t\16\4\17\t\17\3\2\3\2\3\2\3\2\3\2\3\2\3\2\3\3\3\3\3")
        buf.write("\3\7\3)\n\3\f\3\16\3,\13\3\3\4\3\4\3\4\3\4\3\4\3\4\3\4")
        buf.write("\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4A")
        buf.write("\n\4\3\5\3\5\3\5\3\5\5\5G\n\5\3\6\3\6\3\6\3\6\5\6M\n\6")
        buf.write("\3\7\3\7\3\7\3\7\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\7")
        buf.write("\b\\\n\b\f\b\16\b_\13\b\3\t\3\t\3\t\3\t\3\t\3\t\3\t\3")
        buf.write("\t\3\t\7\tj\n\t\f\t\16\tm\13\t\3\n\3\n\3\n\3\n\3\n\3\n")
        buf.write("\5\nu\n\n\3\13\3\13\3\13\3\13\3\13\7\13|\n\13\f\13\16")
        buf.write("\13\177\13\13\3\f\3\f\3\f\3\f\3\f\3\f\3\r\3\r\3\r\3\r")
        buf.write("\3\r\3\r\3\r\5\r\u008e\n\r\3\16\3\16\3\16\3\16\3\17\3")
        buf.write("\17\3\17\3\17\3\17\3\17\5\17\u009a\n\17\3\17\2\6\4\16")
        buf.write("\20\24\20\2\4\6\b\n\f\16\20\22\24\26\30\32\34\2\2\u00a2")
        buf.write("\2\36\3\2\2\2\4%\3\2\2\2\6@\3\2\2\2\bF\3\2\2\2\nL\3\2")
        buf.write("\2\2\fN\3\2\2\2\16R\3\2\2\2\20`\3\2\2\2\22t\3\2\2\2\24")
        buf.write("v\3\2\2\2\26\u0080\3\2\2\2\30\u0086\3\2\2\2\32\u008f\3")
        buf.write("\2\2\2\34\u0099\3\2\2\2\36\37\7\3\2\2\37 \7\4\2\2 !\7")
        buf.write("\5\2\2!\"\7\6\2\2\"#\5\4\3\2#$\7\7\2\2$\3\3\2\2\2%*\b")
        buf.write("\3\1\2&\'\f\4\2\2\')\5\6\4\2(&\3\2\2\2),\3\2\2\2*(\3\2")
        buf.write("\2\2*+\3\2\2\2+\5\3\2\2\2,*\3\2\2\2-.\5\b\5\2./\7\b\2")
        buf.write("\2/A\3\2\2\2\60\61\5\n\6\2\61\62\7\b\2\2\62A\3\2\2\2\63")
        buf.write("A\5\26\f\2\64A\5\30\r\2\65\66\7\6\2\2\66\67\5\4\3\2\67")
        buf.write("8\7\7\2\28A\3\2\2\29:\7\t\2\2:;\7\23\2\2;A\7\b\2\2<=\7")
        buf.write("\t\2\2=>\5\24\13\2>?\7\b\2\2?A\3\2\2\2@-\3\2\2\2@\60\3")
        buf.write("\2\2\2@\63\3\2\2\2@\64\3\2\2\2@\65\3\2\2\2@9\3\2\2\2@")
        buf.write("<\3\2\2\2A\7\3\2\2\2BG\7\23\2\2CG\5\f\7\2DG\5\16\b\2E")
        buf.write("G\5\32\16\2FB\3\2\2\2FC\3\2\2\2FD\3\2\2\2FE\3\2\2\2G\t")
        buf.write("\3\2\2\2HI\7\22\2\2IM\7\23\2\2JK\7\22\2\2KM\5\f\7\2LH")
        buf.write("\3\2\2\2LJ\3\2\2\2M\13\3\2\2\2NO\7\23\2\2OP\7\n\2\2PQ")
        buf.write("\5\b\5\2Q\r\3\2\2\2RS\b\b\1\2ST\5\20\t\2T]\3\2\2\2UV\f")
        buf.write("\5\2\2VW\7\13\2\2W\\\5\20\t\2XY\f\4\2\2YZ\7\f\2\2Z\\\5")
        buf.write("\20\t\2[U\3\2\2\2[X\3\2\2\2\\_\3\2\2\2][\3\2\2\2]^\3\2")
        buf.write("\2\2^\17\3\2\2\2_]\3\2\2\2`a\b\t\1\2ab\5\22\n\2bk\3\2")
        buf.write("\2\2cd\f\5\2\2de\7\r\2\2ej\5\22\n\2fg\f\4\2\2gh\7\16\2")
        buf.write("\2hj\5\22\n\2ic\3\2\2\2if\3\2\2\2jm\3\2\2\2ki\3\2\2\2")
        buf.write("kl\3\2\2\2l\21\3\2\2\2mk\3\2\2\2nu\5\24\13\2op\7\4\2\2")
        buf.write("pq\5\16\b\2qr\7\5\2\2ru\3\2\2\2su\7\23\2\2tn\3\2\2\2t")
        buf.write("o\3\2\2\2ts\3\2\2\2u\23\3\2\2\2vw\b\13\1\2wx\7\24\2\2")
        buf.write("x}\3\2\2\2yz\f\4\2\2z|\7\24\2\2{y\3\2\2\2|\177\3\2\2\2")
        buf.write("}{\3\2\2\2}~\3\2\2\2~\25\3\2\2\2\177}\3\2\2\2\u0080\u0081")
        buf.write("\7\17\2\2\u0081\u0082\7\4\2\2\u0082\u0083\5\b\5\2\u0083")
        buf.write("\u0084\7\5\2\2\u0084\u0085\5\6\4\2\u0085\27\3\2\2\2\u0086")
        buf.write("\u0087\7\20\2\2\u0087\u0088\7\4\2\2\u0088\u0089\5\b\5")
        buf.write("\2\u0089\u008a\7\5\2\2\u008a\u008d\5\6\4\2\u008b\u008c")
        buf.write("\7\21\2\2\u008c\u008e\5\6\4\2\u008d\u008b\3\2\2\2\u008d")
        buf.write("\u008e\3\2\2\2\u008e\31\3\2\2\2\u008f\u0090\5\34\17\2")
        buf.write("\u0090\u0091\7\25\2\2\u0091\u0092\5\34\17\2\u0092\33\3")
        buf.write("\2\2\2\u0093\u009a\7\23\2\2\u0094\u009a\5\24\13\2\u0095")
        buf.write("\u0096\7\4\2\2\u0096\u0097\5\16\b\2\u0097\u0098\7\5\2")
        buf.write("\2\u0098\u009a\3\2\2\2\u0099\u0093\3\2\2\2\u0099\u0094")
        buf.write("\3\2\2\2\u0099\u0095\3\2\2\2\u009a\35\3\2\2\2\16*@FL[")
        buf.write("]ikt}\u008d\u0099")
        return buf.getvalue()


class DevilsCodeParser ( Parser ):

    grammarFileName = "DevilsCode.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'main '", "'('", "')'", "'{'", "'}'", 
                     "';'", "'print '", "'='", "'+'", "'-'", "'*'", "'/'", 
                     "'while '", "'if '", "'else '" ]

    symbolicNames = [ "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "<INVALID>", "<INVALID>", "<INVALID>", "<INVALID>", 
                      "DATA_TYPE", "IDENT", "DIGIT", "CPR_SYMBOL", "WS" ]

    RULE_program = 0
    RULE_stmtlists = 1
    RULE_stmt = 2
    RULE_expr = 3
    RULE_dec_stmt = 4
    RULE_assign_expr = 5
    RULE_math_expr = 6
    RULE_math_term = 7
    RULE_math_factor = 8
    RULE_number = 9
    RULE_while_stmt = 10
    RULE_if_stmt = 11
    RULE_cpr_expr = 12
    RULE_cpr_term = 13

    ruleNames =  [ "program", "stmtlists", "stmt", "expr", "dec_stmt", "assign_expr", 
                   "math_expr", "math_term", "math_factor", "number", "while_stmt", 
                   "if_stmt", "cpr_expr", "cpr_term" ]

    EOF = Token.EOF
    T__0=1
    T__1=2
    T__2=3
    T__3=4
    T__4=5
    T__5=6
    T__6=7
    T__7=8
    T__8=9
    T__9=10
    T__10=11
    T__11=12
    T__12=13
    T__13=14
    T__14=15
    DATA_TYPE=16
    IDENT=17
    DIGIT=18
    CPR_SYMBOL=19
    WS=20

    def __init__(self, input:TokenStream):
        super().__init__(input)
        self.checkVersion("4.5.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None



    class ProgramContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stmtlists(self):
            return self.getTypedRuleContext(DevilsCodeParser.StmtlistsContext,0)


        def getRuleIndex(self):
            return DevilsCodeParser.RULE_program

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterProgram" ):
                listener.enterProgram(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitProgram" ):
                listener.exitProgram(self)




    def program(self):
        isLexicalError = 0
        localctx = DevilsCodeParser.ProgramContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_program)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 28
            self.match(DevilsCodeParser.T__0)
            self.state = 29
            self.match(DevilsCodeParser.T__1)
            self.state = 30
            self.match(DevilsCodeParser.T__2)
            self.state = 31
            self.match(DevilsCodeParser.T__3)
            self.state = 32
            self.stmtlists(0)
            self.state = 33
            self.match(DevilsCodeParser.T__4)
        except RecognitionException as re:
            isLexicalError = 1
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx, isLexicalError	

    class StmtlistsContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def stmtlists(self):
            return self.getTypedRuleContext(DevilsCodeParser.StmtlistsContext,0)


        def stmt(self):
            return self.getTypedRuleContext(DevilsCodeParser.StmtContext,0)


        def getRuleIndex(self):
            return DevilsCodeParser.RULE_stmtlists

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStmtlists" ):
                listener.enterStmtlists(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStmtlists" ):
                listener.exitStmtlists(self)



    def stmtlists(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = DevilsCodeParser.StmtlistsContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 2
        self.enterRecursionRule(localctx, 2, self.RULE_stmtlists, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self._ctx.stop = self._input.LT(-1)
            self.state = 40
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,0,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = DevilsCodeParser.StmtlistsContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_stmtlists)
                    self.state = 36
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 37
                    self.stmt() 
                self.state = 42
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,0,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class StmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self):
            return self.getTypedRuleContext(DevilsCodeParser.ExprContext,0)


        def dec_stmt(self):
            return self.getTypedRuleContext(DevilsCodeParser.Dec_stmtContext,0)


        def while_stmt(self):
            return self.getTypedRuleContext(DevilsCodeParser.While_stmtContext,0)


        def if_stmt(self):
            return self.getTypedRuleContext(DevilsCodeParser.If_stmtContext,0)


        def stmtlists(self):
            return self.getTypedRuleContext(DevilsCodeParser.StmtlistsContext,0)


        def IDENT(self):
            return self.getToken(DevilsCodeParser.IDENT, 0)

        def number(self):
            return self.getTypedRuleContext(DevilsCodeParser.NumberContext,0)


        def getRuleIndex(self):
            return DevilsCodeParser.RULE_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterStmt" ):
                listener.enterStmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitStmt" ):
                listener.exitStmt(self)




    def stmt(self):

        localctx = DevilsCodeParser.StmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_stmt)
        try:
            self.state = 62
            la_ = self._interp.adaptivePredict(self._input,1,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 43
                self.expr()
                self.state = 44
                self.match(DevilsCodeParser.T__5)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 46
                self.dec_stmt()
                self.state = 47
                self.match(DevilsCodeParser.T__5)
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 49
                self.while_stmt()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 50
                self.if_stmt()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 51
                self.match(DevilsCodeParser.T__3)
                self.state = 52
                self.stmtlists(0)
                self.state = 53
                self.match(DevilsCodeParser.T__4)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 55
                self.match(DevilsCodeParser.T__6)
                self.state = 56
                self.match(DevilsCodeParser.IDENT)
                self.state = 57
                self.match(DevilsCodeParser.T__5)
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 58
                self.match(DevilsCodeParser.T__6)
                self.state = 59
                self.number(0)
                self.state = 60
                self.match(DevilsCodeParser.T__5)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class ExprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(DevilsCodeParser.IDENT, 0)

        def assign_expr(self):
            return self.getTypedRuleContext(DevilsCodeParser.Assign_exprContext,0)


        def math_expr(self):
            return self.getTypedRuleContext(DevilsCodeParser.Math_exprContext,0)


        def cpr_expr(self):
            return self.getTypedRuleContext(DevilsCodeParser.Cpr_exprContext,0)


        def getRuleIndex(self):
            return DevilsCodeParser.RULE_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr" ):
                listener.enterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr" ):
                listener.exitExpr(self)




    def expr(self):

        localctx = DevilsCodeParser.ExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_expr)
        try:
            self.state = 68
            la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 64
                self.match(DevilsCodeParser.IDENT)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 65
                self.assign_expr()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 66
                self.math_expr(0)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 67
                self.cpr_expr()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Dec_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DATA_TYPE(self):
            return self.getToken(DevilsCodeParser.DATA_TYPE, 0)

        def IDENT(self):
            return self.getToken(DevilsCodeParser.IDENT, 0)

        def assign_expr(self):
            return self.getTypedRuleContext(DevilsCodeParser.Assign_exprContext,0)


        def getRuleIndex(self):
            return DevilsCodeParser.RULE_dec_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDec_stmt" ):
                listener.enterDec_stmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDec_stmt" ):
                listener.exitDec_stmt(self)




    def dec_stmt(self):

        localctx = DevilsCodeParser.Dec_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_dec_stmt)
        try:
            self.state = 74
            la_ = self._interp.adaptivePredict(self._input,3,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 70
                self.match(DevilsCodeParser.DATA_TYPE)
                self.state = 71
                self.match(DevilsCodeParser.IDENT)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 72
                self.match(DevilsCodeParser.DATA_TYPE)
                self.state = 73
                self.assign_expr()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Assign_exprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(DevilsCodeParser.IDENT, 0)

        def expr(self):
            return self.getTypedRuleContext(DevilsCodeParser.ExprContext,0)


        def getRuleIndex(self):
            return DevilsCodeParser.RULE_assign_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAssign_expr" ):
                listener.enterAssign_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAssign_expr" ):
                listener.exitAssign_expr(self)




    def assign_expr(self):

        localctx = DevilsCodeParser.Assign_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_assign_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 76
            self.match(DevilsCodeParser.IDENT)
            self.state = 77
            self.match(DevilsCodeParser.T__7)
            self.state = 78
            self.expr()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Math_exprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def math_term(self):
            return self.getTypedRuleContext(DevilsCodeParser.Math_termContext,0)


        def math_expr(self):
            return self.getTypedRuleContext(DevilsCodeParser.Math_exprContext,0)


        def getRuleIndex(self):
            return DevilsCodeParser.RULE_math_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMath_expr" ):
                listener.enterMath_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMath_expr" ):
                listener.exitMath_expr(self)



    def math_expr(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = DevilsCodeParser.Math_exprContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 12
        self.enterRecursionRule(localctx, 12, self.RULE_math_expr, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 81
            self.math_term(0)
            self._ctx.stop = self._input.LT(-1)
            self.state = 91
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,5,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 89
                    la_ = self._interp.adaptivePredict(self._input,4,self._ctx)
                    if la_ == 1:
                        localctx = DevilsCodeParser.Math_exprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_math_expr)
                        self.state = 83
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 84
                        self.match(DevilsCodeParser.T__8)
                        self.state = 85
                        self.math_term(0)
                        pass

                    elif la_ == 2:
                        localctx = DevilsCodeParser.Math_exprContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_math_expr)
                        self.state = 86
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 87
                        self.match(DevilsCodeParser.T__9)
                        self.state = 88
                        self.math_term(0)
                        pass

             
                self.state = 93
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,5,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class Math_termContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def math_factor(self):
            return self.getTypedRuleContext(DevilsCodeParser.Math_factorContext,0)


        def math_term(self):
            return self.getTypedRuleContext(DevilsCodeParser.Math_termContext,0)


        def getRuleIndex(self):
            return DevilsCodeParser.RULE_math_term

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMath_term" ):
                listener.enterMath_term(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMath_term" ):
                listener.exitMath_term(self)



    def math_term(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = DevilsCodeParser.Math_termContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 14
        self.enterRecursionRule(localctx, 14, self.RULE_math_term, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 95
            self.math_factor()
            self._ctx.stop = self._input.LT(-1)
            self.state = 105
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,7,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    self.state = 103
                    la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
                    if la_ == 1:
                        localctx = DevilsCodeParser.Math_termContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_math_term)
                        self.state = 97
                        if not self.precpred(self._ctx, 3):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 3)")
                        self.state = 98
                        self.match(DevilsCodeParser.T__10)
                        self.state = 99
                        self.math_factor()
                        pass

                    elif la_ == 2:
                        localctx = DevilsCodeParser.Math_termContext(self, _parentctx, _parentState)
                        self.pushNewRecursionContext(localctx, _startState, self.RULE_math_term)
                        self.state = 100
                        if not self.precpred(self._ctx, 2):
                            from antlr4.error.Errors import FailedPredicateException
                            raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                        self.state = 101
                        self.match(DevilsCodeParser.T__11)
                        self.state = 102
                        self.math_factor()
                        pass

             
                self.state = 107
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,7,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class Math_factorContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def number(self):
            return self.getTypedRuleContext(DevilsCodeParser.NumberContext,0)


        def math_expr(self):
            return self.getTypedRuleContext(DevilsCodeParser.Math_exprContext,0)


        def IDENT(self):
            return self.getToken(DevilsCodeParser.IDENT, 0)

        def getRuleIndex(self):
            return DevilsCodeParser.RULE_math_factor

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMath_factor" ):
                listener.enterMath_factor(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMath_factor" ):
                listener.exitMath_factor(self)




    def math_factor(self):

        localctx = DevilsCodeParser.Math_factorContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_math_factor)
        try:
            self.state = 114
            token = self._input.LA(1)
            if token in [DevilsCodeParser.DIGIT]:
                self.enterOuterAlt(localctx, 1)
                self.state = 108
                self.number(0)

            elif token in [DevilsCodeParser.T__1]:
                self.enterOuterAlt(localctx, 2)
                self.state = 109
                self.match(DevilsCodeParser.T__1)
                self.state = 110
                self.math_expr(0)
                self.state = 111
                self.match(DevilsCodeParser.T__2)

            elif token in [DevilsCodeParser.IDENT]:
                self.enterOuterAlt(localctx, 3)
                self.state = 113
                self.match(DevilsCodeParser.IDENT)

            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class NumberContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def DIGIT(self):
            return self.getToken(DevilsCodeParser.DIGIT, 0)

        def number(self):
            return self.getTypedRuleContext(DevilsCodeParser.NumberContext,0)


        def getRuleIndex(self):
            return DevilsCodeParser.RULE_number

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterNumber" ):
                listener.enterNumber(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitNumber" ):
                listener.exitNumber(self)



    def number(self, _p:int=0):
        _parentctx = self._ctx
        _parentState = self.state
        localctx = DevilsCodeParser.NumberContext(self, self._ctx, _parentState)
        _prevctx = localctx
        _startState = 18
        self.enterRecursionRule(localctx, 18, self.RULE_number, _p)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 117
            self.match(DevilsCodeParser.DIGIT)
            self._ctx.stop = self._input.LT(-1)
            self.state = 123
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,9,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    if self._parseListeners is not None:
                        self.triggerExitRuleEvent()
                    _prevctx = localctx
                    localctx = DevilsCodeParser.NumberContext(self, _parentctx, _parentState)
                    self.pushNewRecursionContext(localctx, _startState, self.RULE_number)
                    self.state = 119
                    if not self.precpred(self._ctx, 2):
                        from antlr4.error.Errors import FailedPredicateException
                        raise FailedPredicateException(self, "self.precpred(self._ctx, 2)")
                    self.state = 120
                    self.match(DevilsCodeParser.DIGIT) 
                self.state = 125
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,9,self._ctx)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.unrollRecursionContexts(_parentctx)
        return localctx

    class While_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self):
            return self.getTypedRuleContext(DevilsCodeParser.ExprContext,0)


        def stmt(self):
            return self.getTypedRuleContext(DevilsCodeParser.StmtContext,0)


        def getRuleIndex(self):
            return DevilsCodeParser.RULE_while_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterWhile_stmt" ):
                listener.enterWhile_stmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitWhile_stmt" ):
                listener.exitWhile_stmt(self)




    def while_stmt(self):

        localctx = DevilsCodeParser.While_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_while_stmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 126
            self.match(DevilsCodeParser.T__12)
            self.state = 127
            self.match(DevilsCodeParser.T__1)
            self.state = 128
            self.expr()
            self.state = 129
            self.match(DevilsCodeParser.T__2)
            self.state = 130
            self.stmt()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class If_stmtContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self):
            return self.getTypedRuleContext(DevilsCodeParser.ExprContext,0)


        def stmt(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(DevilsCodeParser.StmtContext)
            else:
                return self.getTypedRuleContext(DevilsCodeParser.StmtContext,i)


        def getRuleIndex(self):
            return DevilsCodeParser.RULE_if_stmt

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterIf_stmt" ):
                listener.enterIf_stmt(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitIf_stmt" ):
                listener.exitIf_stmt(self)




    def if_stmt(self):

        localctx = DevilsCodeParser.If_stmtContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_if_stmt)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 132
            self.match(DevilsCodeParser.T__13)
            self.state = 133
            self.match(DevilsCodeParser.T__1)
            self.state = 134
            self.expr()
            self.state = 135
            self.match(DevilsCodeParser.T__2)
            self.state = 136
            self.stmt()
            self.state = 139
            la_ = self._interp.adaptivePredict(self._input,10,self._ctx)
            if la_ == 1:
                self.state = 137
                self.match(DevilsCodeParser.T__14)
                self.state = 138
                self.stmt()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Cpr_exprContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def cpr_term(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(DevilsCodeParser.Cpr_termContext)
            else:
                return self.getTypedRuleContext(DevilsCodeParser.Cpr_termContext,i)


        def CPR_SYMBOL(self):
            return self.getToken(DevilsCodeParser.CPR_SYMBOL, 0)

        def getRuleIndex(self):
            return DevilsCodeParser.RULE_cpr_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCpr_expr" ):
                listener.enterCpr_expr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCpr_expr" ):
                listener.exitCpr_expr(self)




    def cpr_expr(self):

        localctx = DevilsCodeParser.Cpr_exprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_cpr_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 141
            self.cpr_term()
            self.state = 142
            self.match(DevilsCodeParser.CPR_SYMBOL)
            self.state = 143
            self.cpr_term()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx

    class Cpr_termContext(ParserRuleContext):

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IDENT(self):
            return self.getToken(DevilsCodeParser.IDENT, 0)

        def number(self):
            return self.getTypedRuleContext(DevilsCodeParser.NumberContext,0)


        def math_expr(self):
            return self.getTypedRuleContext(DevilsCodeParser.Math_exprContext,0)


        def getRuleIndex(self):
            return DevilsCodeParser.RULE_cpr_term

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterCpr_term" ):
                listener.enterCpr_term(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitCpr_term" ):
                listener.exitCpr_term(self)




    def cpr_term(self):

        localctx = DevilsCodeParser.Cpr_termContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_cpr_term)
        try:
            self.state = 151
            token = self._input.LA(1)
            if token in [DevilsCodeParser.IDENT]:
                self.enterOuterAlt(localctx, 1)
                self.state = 145
                self.match(DevilsCodeParser.IDENT)

            elif token in [DevilsCodeParser.DIGIT]:
                self.enterOuterAlt(localctx, 2)
                self.state = 146
                self.number(0)

            elif token in [DevilsCodeParser.T__1]:
                self.enterOuterAlt(localctx, 3)
                self.state = 147
                self.match(DevilsCodeParser.T__1)
                self.state = 148
                self.math_expr(0)
                self.state = 149
                self.match(DevilsCodeParser.T__2)

            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx



    def sempred(self, localctx:RuleContext, ruleIndex:int, predIndex:int):
        if self._predicates == None:
            self._predicates = dict()
        self._predicates[1] = self.stmtlists_sempred
        self._predicates[6] = self.math_expr_sempred
        self._predicates[7] = self.math_term_sempred
        self._predicates[9] = self.number_sempred
        pred = self._predicates.get(ruleIndex, None)
        if pred is None:
            raise Exception("No predicate with index:" + str(ruleIndex))
        else:
            return pred(localctx, predIndex)

    def stmtlists_sempred(self, localctx:StmtlistsContext, predIndex:int):
            if predIndex == 0:
                return self.precpred(self._ctx, 2)
         

    def math_expr_sempred(self, localctx:Math_exprContext, predIndex:int):
            if predIndex == 1:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 2:
                return self.precpred(self._ctx, 2)
         

    def math_term_sempred(self, localctx:Math_termContext, predIndex:int):
            if predIndex == 3:
                return self.precpred(self._ctx, 3)
         

            if predIndex == 4:
                return self.precpred(self._ctx, 2)
         

    def number_sempred(self, localctx:NumberContext, predIndex:int):
            if predIndex == 5:
                return self.precpred(self._ctx, 2)
         



